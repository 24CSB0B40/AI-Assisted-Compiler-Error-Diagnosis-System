// Missing Semicolon #28
#include <iostream>
using namespace std;
int main() {
    int a = 3, b = 4
    cout << a * b << endl;
    return 0;
}
